import HeroSection from "./HeroSection";
import AboutSection from "./AboutSection";
// import ContactSection from "./ContactSection";

export { HeroSection, AboutSection }; 