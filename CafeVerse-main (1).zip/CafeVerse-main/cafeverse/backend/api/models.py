from django.db import models
from accounts import models as AccountModels
# Create your models here.

class Dietary(models.Model):
    name = models.CharField(max_length=20)
    def __str__(self):
        return self.name

class MenuCategory(models.Model):
    category = models.CharField(max_length=30)
    def __str__(self):
        return self.category
    
class Item(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    image = models.URLField()
    popular = models.BooleanField(default=False)
    seasonal = models.BooleanField(default=False)
    calories = models.IntegerField(default=0)
    dietary = models.ManyToManyField(Dietary, blank=True)
    key = models.ForeignKey(MenuCategory, on_delete=models.PROTECT, verbose_name="Category")

    def __str__(self):
        return self.name

class Menu(models.Model):
    key = models.ForeignKey(MenuCategory,on_delete=models.PROTECT)
    name = models.CharField(max_length=30)
    items = models.ManyToManyField(Item)

    def __str__(self):
        return f' {self.key} / ({self.name})'

class Order(models.Model):
    status_choice = (
        ('pending',"Pending"),
        ('delivered',"Delivered"),
        ('completed',"Completed"),
        ('cancelled',"Cancelled"),
    )
    order_type_choice = (
        ('takeaway',"Take Away"),
        ('dinein',"Dine In"),
        ('delivery',"Delivery"),
    )
    payment_method_choice = (
        ('card',"Credit Card"),
        ('UPI',"UPI"),
        ('apple',"Apple Pay"),
        ('cash',"Cash"),
    )
    
    # Basic order information
    user = models.ForeignKey(AccountModels.User,on_delete=models.PROTECT)
    date = models.DateTimeField(auto_now_add=True)
    delivered_at = models.DateTimeField(null=True, blank=True, help_text="Timestamp when order was delivered")
    status = models.CharField(max_length=20,choices=status_choice,default='pending')
    order_type = models.CharField(max_length=20,choices=order_type_choice,default='takeaway')
    
    # Item details (stored as JSON for multiple items)
    items_data = models.JSONField(default=list)  # Store all items as JSON: [{"name": "Latte", "quantity": 2}, ...]
    
    # Financial information
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    
    # Payment details
    payment_method = models.CharField(max_length=20,choices=payment_method_choice,default='card')
    
    # Customer information (always stored)
    customer_name = models.CharField(max_length=100, blank=True, default="Customer")
    
    # Delivery information (only for delivery orders)
    customer_email = models.EmailField(blank=True)
    customer_phone = models.CharField(max_length=20, blank=True)
    address = models.TextField(blank=True, help_text="Complete delivery address for delivery orders")
    delivery_address = models.TextField(blank=True)
    delivery_city = models.CharField(max_length=50, blank=True)
    delivery_zipcode = models.CharField(max_length=10, blank=True)
    
    def __str__(self):
        return f"Order {self.id} - {self.user.username} - {self.status}"
    
    def save(self, *args, **kwargs):
        # Clear delivery-specific fields if not delivery order
        if self.order_type != 'delivery':
            self.customer_email = ''
            self.address = ''
            self.delivery_address = ''
            self.delivery_city = ''
            self.delivery_zipcode = ''
            # Note: customer_phone is preserved for all order types
        
        # Set delivered_at timestamp when status changes to delivered or completed
        if (self.status == 'delivered' or self.status == 'completed') and not self.delivered_at:
            from django.utils import timezone
            self.delivered_at = timezone.now()
        
        super().save(*args, **kwargs)
    
    def get_final_status(self):
        """
        Get the appropriate final status based on order type.
        - Dine-in & Takeaway: 'completed' (food ready)
        - Delivery: 'delivered' (packed and out for delivery)
        """
        if self.order_type in ['dinein', 'takeaway']:
            return 'completed'
        elif self.order_type == 'delivery':
            return 'delivered'
        else:
            return 'pending'
    
    @property
    def items_summary(self):
        """Get a readable summary of all items"""
        if not self.items_data:
            return "No items"
        
        items_list = []
        for item in self.items_data:
            name = item.get('name', 'Unknown Item')
            quantity = item.get('quantity', 1)
            items_list.append(f"{quantity}x {name}")
        
        return ", ".join(items_list)
    
    @property
    def total_items_count(self):
        """Get total number of items"""
        if not self.items_data:
            return 0
        return sum(item.get('quantity', 1) for item in self.items_data)



