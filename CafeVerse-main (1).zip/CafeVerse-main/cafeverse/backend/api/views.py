from django.shortcuts import render,get_list_or_404
from django.http import JsonResponse

from rest_framework.permissions import AllowAny,IsAuthenticated
# Create your views here.
from rest_framework.views import APIView
from rest_framework import generics

from rest_framework.response import Response
from .models import Menu,Item,Order
from accounts.models import User
from .serializers import MenuSerializer,OrderSerializer,ItemSerializer

class MenuView(APIView):
    # serializer_class = MenuSerializer
    # queryset = Menu.objects.all()
    permission_classes = [AllowAny]
    
    def get(self,request):
        data = Menu.objects.all()
        serializer = MenuSerializer(data , many=True)
        return Response({"data":serializer.data} )
    
class OrderView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self,request):
        try:
            # Check if user exists and has customer role
            if not request.user or not hasattr(request.user, 'role') or request.user.role != 'customer':
                return Response({
                    "status": "error",
                    "message": "Only customers can create orders"
                }, status=403)
            
            data = request.data
            print(f"Received order data: {data}")  
            
            # Create single Order record with all items
            from decimal import Decimal
            items_data = data.get('items', [])
            print(f"Items data: {items_data}") 
            
            if not items_data:
                return Response({
                    "status": "error",
                    "message": "No items provided in order"
                }, status=400)
            
            # Prepare items for JSON storage
            order_items = []
            total_amount = Decimal('0.00')
            
            for item_data in items_data:
                print(f"Processing item: {item_data}")  # Debug print
                
                # Calculate item total
                item_price = Decimal(str(item_data.get('price', 0)))
                item_quantity = item_data.get('quantity', 1)
                item_total = item_price * item_quantity
                total_amount += item_total
                
                # Add item to order items list
                order_items.append({
                    'name': item_data.get('item_name', 'Unknown Item'),
                    'quantity': item_quantity,
                    'price': float(item_price),
                    'total': float(item_total)
                })
            
            # Create single order with all items
            order = Order.objects.create(
                user=request.user,
                order_type=data.get('order_type', 'takeaway'),
                payment_method=data.get('payment_method', 'card'),
                customer_name=data.get('customer_name', request.user.username or 'Customer'),
                items_data=order_items,
                total_amount=total_amount,
                customer_email=data.get('customer_email', ''),
                customer_phone=data.get('customer_phone', ''),
                address=data.get('address', ''),  # New address field
                delivery_address=data.get('delivery_address', ''),
                delivery_city=data.get('delivery_city', ''),
                delivery_zipcode=data.get('delivery_zipcode', '')
            )
            print(f"Created Order: {order} with {len(order_items)} items")  # Debug print
            
            return Response({
                'status': 'success',
                'order_id': order.id,
                'message': f'Order created successfully with {len(order_items)} items'
            })
            
        except Exception as e:
            print(f"Error creating order: {e}")
            return Response({
                "status": "error",
                "message": f"Failed to create order: {str(e)}"
            }, status=400)
        
    def get(self,request):
        try:
            if not request.user or not hasattr(request.user, 'role'):
                return Response({
                    "status": "error",
                    "message": "User not authenticated"
                }, status=401)
                
            if request.user.role == 'customer':    
                orders = Order.objects.filter(user=request.user).order_by('-date')
                serializer = OrderSerializer(orders,many=True)
                return Response({"data":serializer.data})
            else:
                pending_orders = Order.objects.filter(status='pending').order_by('-date')
                completed_orders= Order.objects.filter(status='completed').order_by('date')
                pendings= OrderSerializer(pending_orders,many=True)
                completed= OrderSerializer(completed_orders,many=True)
                return Response({
                    "pending":pendings.data,
                    "completed":completed.data
                },status=200)
        except Exception as e:
            print(f"Error fetching orders: {e}")
            return Response({
                "status":"error", 
                "message": f"Failed to fetch orders: {str(e)}"
            }, status=400)

    def patch(self, request):
        """Cancel order - for customers to cancel their own orders"""
        try:
            if not request.user or not hasattr(request.user, 'role'):
                return Response({
                    "status": "error",
                    "message": "User not authenticated"
                }, status=401)
            
            if request.user.role != 'customer':
                return Response({
                    "status": "error",
                    "message": "Only customers can cancel their own orders"
                }, status=403)
            
            order_id = request.data.get('order_id')
            if not order_id:
                return Response({
                    "status": "error",
                    "message": "Order ID is required"
                }, status=400)
            
            try:
                order = Order.objects.get(id=order_id, user=request.user)
            except Order.DoesNotExist:
                return Response({
                    "status": "error",
                    "message": "Order not found or you don't have permission to cancel this order"
                }, status=404)
            
            # Only allow cancellation of pending orders
            if order.status != 'pending':
                return Response({
                    "status": "error",
                    "message": "Only pending orders can be cancelled"
                }, status=400)
            
            order.status = 'cancelled'
            order.save()
            
            serializer = OrderSerializer(order)
            return Response({
                "status": "success",
                "message": f"Order #{order_id} has been cancelled successfully",
                "order": serializer.data
            })
            
        except Exception as e:
            print(f"Error cancelling order: {e}")
            return Response({
                "status": "error",
                "message": f"Failed to cancel order: {str(e)}"
            }, status=400)


class OrderDetailsView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]

    def update(self, request, *args, **kwargs):
        if request.user.role != 'admin':
            return Response({"Error":"Only admins can update order status."})
        return super().update(request, *args, **kwargs)

class AdminOrdersView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        """Get all orders for admin dashboard"""
        try:
            if request.user.role != 'admin':
                return Response({
                    "status": "error",
                    "message": "Only admins can view all orders"
                }, status=403)
            
            orders = Order.objects.all().order_by('-date')
            serializer = OrderSerializer(orders, many=True)
            return Response(serializer.data)
            
        except Exception as e:
            print(f"Error fetching orders: {e}")
            return Response({
                "status": "error",
                "message": f"Failed to fetch orders: {str(e)}"
            }, status=400)
    
    def patch(self, request, order_id):
        """Update order status"""
        try:
            if request.user.role != 'admin':
                return Response({
                    "status": "error",
                    "message": "Only admins can update order status"
                }, status=403)
            
            order = Order.objects.get(id=order_id)
            action = request.data.get('action')  # 'mark_complete' or 'mark_delivered'
            
            # Determine the appropriate status based on order type
            if action == 'mark_complete':
                if order.order_type in ['dinein', 'takeaway']:
                    new_status = 'completed'
                elif order.order_type == 'delivery':
                    new_status = 'delivered'
                else:
                    new_status = 'completed'  # Default fallback
            elif action == 'mark_delivered':
                if order.order_type == 'delivery':
                    new_status = 'delivered'
                else:
                    new_status = 'completed'  # For dine-in/takeaway, use completed
            else:
                return Response({
                    "status": "error",
                    "message": "Invalid action. Use 'mark_complete' or 'mark_delivered'"
                }, status=400)
            
            order.status = new_status
            order.save()
            
            serializer = OrderSerializer(order)
            return Response({
                "status": "success",
                "message": f"Order #{order_id} marked as {new_status}",
                "order": serializer.data
            })
            
        except Order.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Order not found"
            }, status=404)
        except Exception as e:
            print(f"Error updating order status: {e}")
            return Response({
                "status": "error",
                "message": f"Failed to update order status: {str(e)}"
            }, status=400)
    
class ItemDetailsView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer
    permission_classes = [IsAuthenticated]

    def update(self,request,*args,**kwargs):
        if request.user.role != 'admin':
            return Response({"Error":"Only admins can update Items."})
        return super().update(request, *args, **kwargs)
    
    def delete(self,request, pk):
        if request.user.role != 'admin':
            return Response({"Error":"Only admins can delete Items."})
        try:
            order = self.get_object()
            order.delete()
            return Response({"message": "Order deleted successfully."})
        except Order.DoesNotExist:
            return Response({"error": "Order not found."},status=404)