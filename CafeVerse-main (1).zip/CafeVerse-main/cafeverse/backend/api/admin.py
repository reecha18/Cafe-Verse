from django.contrib import admin
from django import forms

# Register your models here.
from .models import Menu,MenuCategory,Dietary,Item,Order

admin.site.register(Menu)
admin.site.register(Dietary)
admin.site.register(MenuCategory)
admin.site.register(Item)
admin.site.register(Order)