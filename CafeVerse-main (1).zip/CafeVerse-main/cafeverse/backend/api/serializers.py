from rest_framework import serializers
# from .models import MenuItem, Category, Table, Order, OrderItem
from .models import Menu,Item,MenuCategory,Dietary,Order
from accounts.serializers import UserSerializer


class DietarySerializer(serializers.ModelSerializer):
    class Meta:
        model = Dietary
        fields = ['name']

class MenuCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuCategory
        fields = ['category']

class ItemSerializer(serializers.ModelSerializer):
    key = MenuCategorySerializer()
    dietary = DietarySerializer(many=True)
    class Meta:
        model = Item
        fields = '__all__'

class MenuSerializer(serializers.ModelSerializer):
    key = MenuCategorySerializer()
    items = ItemSerializer(many=True)
    class Meta:
        model = Menu
        fields = ['id','key','name','items']



class OrderSerializer(serializers.ModelSerializer):
    user = UserSerializer()
    items_summary = serializers.ReadOnlyField()
    total_items_count = serializers.ReadOnlyField()
    created_at = serializers.DateTimeField(source='date', read_only=True)
    delivered_at = serializers.DateTimeField(read_only=True)
    phone_number = serializers.CharField(source='customer_phone', read_only=True)
    items = serializers.SerializerMethodField()
    
    class Meta:
        model = Order
        fields = [
            'id', 'user', 'created_at', 'delivered_at', 'status', 'order_type', 'items_data', 'items', 'items_summary', 'total_items_count',
            'total_amount', 'payment_method', 'customer_name',
            'customer_email', 'phone_number', 'delivery_address', 'delivery_city', 'delivery_zipcode'
        ]
    
    def get_items(self, obj):
        """Format items_data for frontend consumption"""
        if not obj.items_data:
            return []
        
        return [
            {
                'name': item.get('name', 'Unknown Item'),
                'quantity': item.get('quantity', 1),
                'price': item.get('price', 0),
                'total': item.get('total', 0)
            }
            for item in obj.items_data
        ]

# class CategorySerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Category
#         fields = '__all__'

# class MenuItemSerializer(serializers.ModelSerializer):
#     category = CategorySerializer()

#     class Meta:
#         model = MenuItem
#         fields = '__all__'

# class OrderItemSerializer(serializers.ModelSerializer):
#     menu_item = MenuItemSerializer()

#     class Meta:
#         model = OrderItem
#         fields = '__all__'

# class OrderSerializer(serializers.ModelSerializer):
#     items = OrderItemSerializer(many=True)

#     class Meta:
#         model = Order
#         fields = '__all__'